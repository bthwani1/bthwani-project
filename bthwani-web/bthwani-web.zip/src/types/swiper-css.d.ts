declare module "swiper/css";
declare module "swiper/css/pagination";
