// src/features/utilityWater/constants.ts
export const QTY_MIN = 1;
export const QTY_MAX = 20;
export const SIZE_ORDER: ("small" | "medium" | "large")[] = [
  "small",
  "medium",
  "large",
];
