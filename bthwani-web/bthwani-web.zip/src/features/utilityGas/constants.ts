export const QTY_MAX = 50;
export const QTY_MIN_FALLBACK = 1;