import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n
  .use(initReactI18next)
  .init({
    resources: {
      ar: {
        translation: {}
      },
      en: {
        translation: {}
      }
    },
    lng: 'ar',
    fallbackLng: 'ar',
    interpolation: {
      escapeValue: false
    }
  });

// Load translations
fetch('/locales/ar/translation.json')
  .then(res => res.json())
  .then(data => {
    i18n.addResourceBundle('ar', 'translation', data);
  });

fetch('/locales/en/translation.json')
  .then(res => res.json())
  .then(data => {
    i18n.addResourceBundle('en', 'translation', data);
  });

export default i18n;
