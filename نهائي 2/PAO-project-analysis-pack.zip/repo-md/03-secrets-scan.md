# مسح أسرار مُحتملة (Heuristic)
وقت التحليل: 2025-10-22 17:03:00Z UTC

النتيجة: **81** تطابقًا محتملًا. يجب المراجعة والتأكد أنها ليست قيمًا وهمية.

- `bthwani-project-main/PHASE_1_COMPLETION_REPORT.md` — GCP API key — `ase API Key مكشوف: `AIzaSyCN6cX8lKQgEkMkEXsMKJjljRJQqlY_yzY` - 🚨 MongoDB Produc`
- `bthwani-project-main/SECURITY_ENV_SETUP.md` — GCP API key — `لقيم المكشوفة:** - `AIzaSyCN6cX8lKQgEkMkEXsMKJjljRJQqlY_yzY` (admin-dashboard) `
- `bthwani-project-main/SECURITY_ENV_SETUP.md` — GCP API key — `admin-dashboard) - `AIzaSyDcj9GF6Jsi7aIWHoOmH9OKwdOs2pRswS0` (bthwani-web)  **ا`
- `bthwani-project-main/admin-dashboard/src/components/LocationPicker.tsx` — GCP API key — ` const GMAPS_KEY = "AIzaSyB7rdwWNFGT9rt2jo1xn5PJKGDnaHG5sZI";  const COLORS = {`
- `bthwani-project-main/admin-dashboard/src/examples/dashboard-integration.tsx` — Generic secret literal — `admin'],     },     token: 'your-jwt-token-here',   }; }  function u`
- `bthwani-project-main/app-user/app.json` — GCP API key — `         "apiKey": "AIzaSyCoIo_MvZY0h5r1ipzg6fvn6S_iTF3VslA"         }       },`
- `bthwani-project-main/app-user/google-services.json` — GCP API key — `    "current_key": "AIzaSyDcj9GF6Jsi7aIWHoOmH9OKwdOs2pRswS0"         }       ],`
- `bthwani-project-main/app-user/src/__tests__/api/authService.test.ts` — Generic secret literal — ` => {       const idToken = "test-id-token";       const refres`
- `bthwani-project-main/app-user/src/__tests__/api/authService.test.ts` — Generic secret literal — `       const refreshToken = "test-refresh-token";       const expire`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `a: { ok: true, resetToken: "reset-token-123" },       };       (`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `al({ ok: true, resetToken: "reset-token-123" });     });      te`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `a: { ok: true, resetToken: "reset-token-123" },       };       (`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `;        const resetToken = "reset-token-123";       const newPas`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `23";       const newPassword = "newPassword123";       const result`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `;        const resetToken = "reset-token-123";       const newPas`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `23";       const newPassword = "newPassword123";        await expec`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `;        const resetToken = "reset-token-123";       const newPas`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `23";       const newPassword = "newPassword123";        await expec`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — ` "";       const newPassword = "newPassword123";        await expec`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `;        const resetToken = "reset-token-123";       const newPas`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — `a: { ok: true, resetToken: "reset-token-123" },       };       (`
- `bthwani-project-main/app-user/src/__tests__/api/passwordResetApi.test.ts` — Generic secret literal — ` true,         resetToken: "reset-token-123",       });        /`
- `bthwani-project-main/app-user/src/__tests__/screens/Auth/ResetNewPasswordScreen.test.tsx` — Generic secret literal — `arams: {       resetToken: 'test-reset-token',       email: 'test`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — `> {       const mockToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIi`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — `> {       const mockToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIi`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — ` {       const validToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIi`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — `       const invalidToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwfQ`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — `       const invalidToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwfQ`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — ` {       const validToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIi`
- `bthwani-project-main/app-user/src/__tests__/utils/api/token.test.ts` — Generic secret literal — `       const expiredToken =         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIi`
