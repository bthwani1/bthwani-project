# حزم Node (package.json)
وقت التحليل: 2025-10-22 17:03:00Z UTC

إجمالي package.json: **8**

- `bthwani-project-main/package.json` — name: `` — deps: 1 — devDeps: 6
- `bthwani-project-main/admin-dashboard/package.json` — name: `admin-dashboard` — deps: 40 — devDeps: 27
- `bthwani-project-main/app-user/package.json` — name: `bthwaniapp` — deps: 67 — devDeps: 14
- `bthwani-project-main/backend-nest/package.json` — name: `bthwani-backend-nest` — deps: 39 — devDeps: 29
- `bthwani-project-main/bthwani-web/package.json` — name: `bthwani-web` — deps: 30 — devDeps: 23
- `bthwani-project-main/field-marketers/package.json` — name: `field-marketers` — deps: 26 — devDeps: 8
- `bthwani-project-main/rider-app/package.json` — name: `rider-app` — deps: 38 — devDeps: 8
- `bthwani-project-main/vendor-app/package.json` — name: `vendor-app` — deps: 52 — devDeps: 12
