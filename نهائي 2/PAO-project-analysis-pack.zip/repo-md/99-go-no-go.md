# Go/No-Go — مسودة
- Contracts parity ≤5%: TBD
- OAS lint + uniqueness: TBD
- Secrets found=0: FAIL
- Critical CVEs>48h: TBD
- NetPol ≥90%: TBD
- LCP p75 ≤2.5s, INP ≤200ms: TBD
- DR drill ≤90d: TBD
- Payments variance ≤0.1%: TBD
- Notifications delivery ≥95%: TBD

> اكمل الأدلة ثم حدد القرار النهائي.
